import yatpkg.util.mos as tools
from yatpkg.util.data import StorageIO, StorageType, resample, Yatsdo
from yatpkg.math.filters import process_data, Butterworth
import skinematics.imus as sk
import numpy as np
from yatpkg.math.transformation import Quaternion, PCAModel
import os
import matplotlib.pyplot as plt
import scipy.stats as stats
from enum import Enum

from multiprocessing import Pool


class Worker(object):
    def __init__(self, thread_id, name, cache):
        self.thread_id = thread_id
        self.name = name
        self.cache = cache

    def run(self):
        return 0


class WorkerMadgwick(Worker):
    # For the orientation determined by the madgwick filter
    # The imu should be in xyz rotation order i.e. a = euler, a[0] = yaw/z, a[1] = pitch/x, a[2] = roll/y,
    # but for the foot it is same xyz rotation order but a = euler, a[0] = yaw/z, a[1] = roll/y, a[2] = pitch/x,
    def __init__(self, thread_id, name, cache):
        super().__init__(thread_id, name, cache)

    def run(self):
        acc = self.cache['acc']
        gyr = self.cache['gyr']
        imu = self.cache['imu']
        d = []
        for i in range(0, acc.shape[0]):
            imu.Update(gyr[i, :], acc[i, :], np.array([0, 0, 0]))
            d.append(imu.Quaternion)
        return np.array(d)


class WorkerStatic(Worker):
    def __init__(self, thread_id, name, cache):
        super().__init__(thread_id, name, cache)

    def run(self):
        gyr = self.cache['gyr']
        step = self.cache['step']
        thres = self.cache['thres']
        stdv = [np.nanstd([np.linalg.norm(gyr[i, :]) for i in range(0, j)]) for j in range(200, gyr.shape[0], step)]
        frames = [int(i * step) + 200 for i in range(0, len(stdv) - 1) if stdv[i] < (thres * (np.pi / 180))]
        return frames[-1]


class WorkerRemoveYaw(Worker):
    def __init__(self, thread_id, name, cache):
        super().__init__(thread_id, name, cache)

    def run(self):
        ori = self.cache['ori']
        # Create helper Quaternion class
        imus_ori_q_class = [Quaternion(ori[i, :]) for i in range(0, ori.shape[0])]
        # to euler
        imus_ori_ypr = np.array(
            [imus_ori_q_class[i].to_euler('xyz') for i in range(0, ori.shape[0])])
        # remove yaw
        temp = [[0, imus_ori_ypr[i][1], imus_ori_ypr[i][2]] for i in range(0, imus_ori_ypr.shape[0])]

        # recreate helper Quaternion class
        imus_ori_tilt_q = [Quaternion.create_from_euler('xyz', temp[i]) for i in
                                range(0, imus_ori_ypr.shape[0])]
        displ = [imus_ori_tilt_q[i].to_array() for i in range(0, imus_ori_ypr.shape[0])]
        return {"q_class": imus_ori_tilt_q, "q_array": np.array(displ)}


class WorkerRemoveGravity(Worker):
    def __init__(self, thread_id, name, cache):
        super().__init__(thread_id, name, cache)

    def run(self):
        ori = self.cache['ori']
        accs = self.cache['acc']
        gyrs = self.cache['gyr']
        acc_rmg = np.zeros([accs.shape[0], 3])
        gyr_g = np.zeros([gyrs.shape[0], 3])
        accq0 = np.zeros([accs.shape[0], 3])
        for i in range(0, accs.shape[0]):
            acc = accs[i, :]
            gyr = gyrs[i, :]
            acca = Quaternion([0, acc[0], acc[1], acc[2]], is_rotation=False)
            gyra = Quaternion([0, gyr[0], gyr[1], gyr[2]], is_rotation=False)
            imu_inv = ori[i].inverse()
            acc_qrm = imu_inv.conjugate() * (acca * imu_inv)
            gyr_qrm = imu_inv.conjugate() * (gyra * imu_inv)
            accq = acc_qrm.to_array()
            gyrq = gyr_qrm.to_array()
            accq0[i, :] = accq[1:4]
            gyr_g[i, :] = gyrq[1:4]
            acc_rmg[i, :] = accq[1:4] - np.array([0, 0, 9.81])
        return {"acc": acc_rmg, "gyr": gyr_g}


def job_to_do(worker):
    return [worker.name, worker.run_single()]


class ScaleFactors(Enum):
    mm2m = 0.001
    m2mm = 1000
    deg2rad = np.pi/180
    rad2deg = 180/np.pi


class BasicIMUFilter:
    @staticmethod
    def madgwick_mag(imus, imus_resampled, imu_labels, imus_madgwick, m, t_rate):
        workers = []
        for imu in imus:
            acc = imus_resampled[imu][imu_labels[imu]['acc']].to_numpy()
            gyr = imus_resampled[imu][imu_labels[imu]['gyr']].to_numpy()
            gyr = np.matmul(np.diag([np.pi / 180, np.pi / 180, np.pi / 180]), gyr.transpose()).transpose()
            im = imus_madgwick[imu]
            job = {'acc': acc[:int(m / 2), :], 'gyr': gyr[:int(m / 2), :], 'imu': im}
            worker = WorkerMadgwick(1, imu, job)
            workers.append(worker)

        with Pool() as pool:
            result = pool.map(job_to_do, workers)
        return result

    @staticmethod
    def madgwick(imus, imus_resampled, imu_labels, imus_madgwick, m, t_rate):
        # Madgwick first pass
        workers = []
        for imu in imus:
            acc = imus_resampled[imu][imu_labels[imu]['acc']].to_numpy()
            gyr = imus_resampled[imu][imu_labels[imu]['gyr']].to_numpy()
            gyr = np.matmul(np.diag([np.pi / 180, np.pi / 180, np.pi / 180]), gyr.transpose()).transpose()
            im = imus_madgwick[imu]
            job = {'acc': acc[:int(m / 2), :], 'gyr': gyr[:int(m / 2), :], 'imu': im}
            worker = WorkerMadgwick(1, imu, job)
            workers.append(worker)

        with Pool() as pool:
            result = pool.map(job_to_do, workers)

        imus_ori = {}
        for i in range(0, len(result)):
            q = result[i][1][-1, :]
            imus_madgwick[result[i][0]] = sk.Madgwick(rate=t_rate, Beta=0.99, Quaternion=q)
            imus_ori[result[i][0]] = result[i][1]

        # Madgwick second pass
        workers = []
        for imu in imus:
            acc = imus_resampled[imu][imu_labels[imu]['acc']].to_numpy()
            gyr = imus_resampled[imu][imu_labels[imu]['gyr']].to_numpy()
            gyr = np.matmul(np.diag([np.pi / 180, np.pi / 180, np.pi / 180]), gyr.transpose()).transpose()
            im = imus_madgwick[imu]
            job = {'acc': acc[:int(m / 2), :], 'gyr': gyr[:int(m / 2), :], 'imu': im}
            worker = WorkerMadgwick(1, imu, job)
            workers.append(worker)

        with Pool() as pool:
            result = pool.map(job_to_do, workers)

        # Madgwick Final pass
        imus_ori = {}
        for i in range(0, len(result)):
            q = result[i][1][-1, :]
            imus_madgwick[result[i][0]] = sk.Madgwick(rate=t_rate, Beta=0.45, Quaternion=q)
            imus_ori[result[i][0]] = result[i][1]

        workers = []
        for imu in imus:
            acc = imus_resampled[imu][imu_labels[imu]['acc']].to_numpy()
            gyr = imus_resampled[imu][imu_labels[imu]['gyr']].to_numpy()
            gyr = np.matmul(np.diag([np.pi / 180, np.pi / 180, np.pi / 180]), gyr.transpose()).transpose()
            im = imus_madgwick[imu]
            job = {'acc': acc, 'gyr': gyr, 'imu': im}
            worker = WorkerMadgwick(1, imu, job)
            workers.append(worker)

        with Pool() as pool:
            result = pool.map(job_to_do, workers)
        return result

    @staticmethod
    def find_static(imus, imus_resampled, imu_labels):
        workers = []
        for imu in imus:
            gyr = imus_resampled[imu][imu_labels[imu]['gyr']].to_numpy()
            gyr = np.matmul(np.diag([np.pi / 180, np.pi / 180, np.pi / 180]), gyr.transpose()).transpose()
            job = {'gyr': gyr, 'step': 200}
            worker = WorkerStatic(1, imu, job)
            workers.append(worker)

        with Pool() as pool:
            result = pool.map(job_to_do, workers)
        print(result)
        static_poll = [result[i][1] for i in range(0, len(result))]
        m = stats.mode(static_poll)[0][0]
        return m

    @staticmethod
    def run(s, para):
        print("BasicIMUFilter")
        cs = para['linear_scale']
        rs = para['rotation_scale']
        s.find_dt()
        imus = s.separate(para['column_labels'], first_col=para['first_col'])
        imus_filtered = {}
        imus_resampled = {}
        # butterworth filter and downsample
        t_rate = para['target_rate']
        for imu in imus:
            imus_filtered[imu] = process_data(imus[imu], Butterworth.butter_low_pass,
                                              para=[para["butterworth_low_cutoff"], 1/s.info['dt']])
            imus_resampled[imu] = resample(imus_filtered[imu], t_rate)

        # Sort data to acc and gyro
        accl = para['acc_label']
        gyrl = para['gyr_label']
        imus_madgwick = {}
        imu_labels = {}
        for imu in imus:
            imus_madgwick[imu] = sk.Madgwick(rate=t_rate, Beta=0.99)
            temp = {}
            acc_ = []
            gyr_ = []
            for c in imus_resampled[imu].columns:
                for a in accl:
                    if c.lower().endswith(a.lower()):
                        acc_.append(c)
                for a in gyrl:
                     if c.lower().endswith(a.lower()):
                        gyr_.append(c)
            temp['acc'] = sorted(acc_)
            temp['gyr'] = sorted(gyr_)
            imu_labels[imu] = temp

        # find static
        print("Find Static")
        static_thres = para['static_threshold']
        m = BasicIMUFilter.find_static(imus, imus_resampled, imu_labels)

        print("Run Madgwick")
        result = BasicIMUFilter.madgwick(imus, imus_resampled, imu_labels, imus_madgwick, m, t_rate)

        # extract results
        imus_ori = {}
        workers = []
        for i in range(0, len(result)):
            imus_ori[result[i][0]] = result[i][1]
            job = {'ori': imus_ori[result[i][0]]}
            worker = WorkerRemoveYaw(1, result[i][0], job)
            workers.append(worker)
        print("Madgwick Done")

        pass
        print("Remove Yaw")
        # Remove yaw and recompose Quaternion()
        with Pool() as pool:
            result = pool.map(job_to_do, workers)

        imus_ori_q_removed = {}
        for i in range(0, len(result)):
            imus_ori_q_removed[result[i][0]] = result[i][1]
        print("Yaw Removed")

        # remove gravity from acceleration
        print("Remove gravity")

        workers = []
        for imu in imus:
            accs = imus_resampled[imu][imu_labels[imu]['acc']].to_numpy()
            accs = np.matmul(np.diag([cs.value, cs.value, cs.value]), accs.transpose()).transpose()
            gyr = imus_resampled[imu][imu_labels[imu]['gyr']].to_numpy()
            gyr = np.matmul(np.diag([rs.value, rs.value, rs.value]), gyr.transpose()).transpose()
            q = imus_ori_q_removed[imu]['q_class']
            job = {'ori': q, 'acc': accs, 'gyr': gyr}
            worker = WorkerRemoveGravity(1, imu, job)
            workers.append(worker)

        with Pool() as pool:
            result = pool.map(job_to_do, workers)

        imus_acc_rmg = {}
        imus_gyr_g = {}
        for i in range(0, len(result)):
            imus_acc_rmg[result[i][0]] = result[i][1]["acc"]
            imus_gyr_g[result[i][0]] = result[i][1]["gyr"]

        print("Gravity Removed")
        return {'acc_g_removed': imus_acc_rmg,
                'gyr_g_adjusted': imus_gyr_g,
                'imus': imus}


class BlueTrident(BasicIMUFilter):
    @staticmethod
    def quick_combine_and_filter(low_g, mag, target_rate=100, low_pass=[6, 6], remove_jitter=False, out_file=None):
        """
        This method combines the low_g and mag data into one data frame as well as downsampling the data
        to a target sampling rate.
        :param low_g:
        :param mag:
        :param target_rate:
        :param low_pass:
        :param remove_jitter:
        :param out_file:
        :return:
        """
        s0 = StorageIO.load(
            low_g,
            StorageType.csv)
        s1 = StorageIO.load(
            mag,
            StorageType.csv)
        rate = target_rate
        df0 = s0.to_yatsdo(remove_jitter)
        a = df0.filter(Butterworth.butter_low_pass, para=[low_pass[0], 1 / s0.info['dt']])
        df1 = s1.to_yatsdo(remove_jitter)
        b = df1.filter(Butterworth.butter_low_pass, para=[low_pass[1], 1 / s1.info['dt']])
        ys = Yatsdo.combine(a, b, rate)
        if out_file is not None:
            ys.to_csv(out_file)
        return ys

    @staticmethod
    def run(s, para):
        return


if __name__ == '__main__':
    # for testing
    drive_letter = tools.find_drive_letter("Samsung_T5")
    s0 = StorageIO.load(
        drive_letter + "/Github/simulathor/validation_data_part_2/treadmill/P08/IMU/Walk/ProcessedIMUWalk03.mot",
        StorageType.mot)
    paras = {'linear_scale': ScaleFactors.mm2m,
             'rotation_scale': ScaleFactors.deg2rad,
             'column_labels': ['foot', 'shank', 'thigh', 'pelvis'],
             'first_col': 'time',
             'target_rate': 200,
             'butterworth_low_cutoff': 6}
    BasicIMUFilter.run(s0, paras)
    pass
