from yatpkg.mlde.ml_util import MLOperations, YatsdoML, Participants, Participant
from yatpkg.mlde.tags import MLKeys
from yatpkg.util.data import StorageIO, StorageType
from yatpkg.math.filters import Butterworth
from yatpkg.math.general import DataError
import pandas as pd
import numpy as np
from typing import Optional, List, Union
import json
import os

from tsfresh.feature_extraction.settings import from_columns
from tsfresh.feature_selection.relevance import calculate_relevance_table
import time

"""
This is an example script of how to use the yatpkg with tsfresh

"""


class Poop(object):

    @staticmethod
    def time_match(one_poop: pd.DataFrame, two_poop: pd.DataFrame):
        """
        This method get data from data frame two that matches the time point of data frame one
        :param one_poop: reference data frame
        :param two_poop: data frame to be adjusted by ref
        :return:
        """
        pooh_1 = YatsdoML(one_poop)
        pooh_2 = YatsdoML(two_poop)
        my_time = pooh_1.time
        new_poohs_2 = pooh_2.get_samples(my_time)
        return new_poohs_2

    @staticmethod
    def scale(data: np.ndarray, s: Optional[Union[np.ndarray, List]]):
        """
        This methods scales the input data. For this module it is recommended to scale the values to base S.I. units
        and radians for angular values
        :param data: n x m matrix where n (rows) are the degrees of freedom/generalised coordinates and m is the
        instance or sample of the degrees of freedom/generalised coordinates
        :param s: is the scale factor for each degrees of freedom
        :return: a scaled matrix (ndarray)
        """
        if data.shape[0] != len(s):
            raise ValueError(
                "data first dimension must be the same as length of s.\n\tdata = {:d}, s = {:d}".format(data.shape[0],
                                                                                                        len(s)))
        return np.matmul(np.diag(s), data)

    @staticmethod
    def filter_noise(a, b_dt, cut_off=6, order=3):
        """
        Generic noise filtering using Butterworth filter
        :param order: default = 3 (The maximum delay, in samples, used in creating each output sample,
        https://ccrma.stanford.edu/~jos/filters/Filter_Order.html)
        :param a: data (data frame)
        :param b_dt: the sampling rate
        :param cut_off: cut off frequency (default = 6)
        :return: filtered data (data frame)
        """
        for na in a.columns:
            if na == 'time' or na == 'Time':
                continue
            a.loc[:, na] = Butterworth.butter_low_filter(a[na], cut_off, fs=1 / b_dt, order=order)
        return a

    @staticmethod
    def merge_channels(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        print("Create super file .....")
        for p in px:
            print(p, end=" ")
            print(".", end=" ")
            p_dir = p0t.output_dir + "/features_LOO/" + p + "/"
            list_p = os.listdir(p_dir)
            count = 0
            shape = None
            for f in list_p:
                if shape is None:
                    if f.endswith("features.h5"):
                        the_file = p_dir + f
                        the_features = pd.read_hdf(the_file, key=MLKeys.full_features.name)
                        shape = the_features.shape
                if f.endswith("features.h5"):
                    count += 1

            combine = np.zeros([shape[0], shape[1]*count])
            print("Number of Channels: " + str(count))
            print("Matrix Setup: " + str(combine.shape))
            print("Creating Matrix ")
            index = 0
            cols = []
            for f in list_p:
                if f.endswith("features.h5"):
                    the_file = p_dir+f
                    the_features = pd.read_hdf(the_file, key=MLKeys.full_features.name)
                    print(".", end=" ")
                    # print(the_features.shape, end=" ")
                    x = index*shape[1]
                    y = x+shape[1]
                    # print(str(x)+" "+str(y))
                    # print(combine.shape)
                    combine[:, x:y] = the_features.to_numpy()
                    for c in the_features.columns:
                        cols.append(c)
                    pass
                    index += 1
            df = pd.DataFrame(data=combine, columns=cols)
            print(" write out ... ", end=" ")
            df.to_hdf(p_dir+p+"_features_loo.h5", key=MLKeys.full_features.name)
            print("done")
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)
            print()

    @staticmethod
    def train(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        print("Create super file .....")
        for p in px:
            print(p, end=" ")
            print(" training .", end=" ")
            the_file = p0t.output_dir + "/features_LOO/" + p + "/" + p+"_features_loo.h5"
            the_features = pd.read_hdf(the_file, key=MLKeys.full_features.name)
            print(".", end=" ")
            y = pd.read_hdf(p0t.output_dir+"/LOO_inputs/"+p+"_data.h5", key="y")
            print(".", end=" ")
            model = MLOperations.train_model(the_features, y)
            print(".", end=" ")
            MLOperations.export_model(model[MLKeys.model.name], p0t.output_dir+"/LOO_models/"+p+"_model_loo.pkl")
            importance_sorted, features_names = MLOperations.sort_features_all(model[MLKeys.feature_importance.name])
            print(". exporting ...", end=" ")
            MLOperations.export_features(importance_sorted, features_names,
                                         p0t.output_dir + "/features_LOO/",
                                         p + '_LOO_' + MLKeys.importance_sorted.name,
                                         table_id=MLKeys.importance_sorted.name)
            pass
            print("Done!")
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)

    @staticmethod
    def Chunk_LOO(p0t: Participants, exclude: str = None):
        px = p0t.participants_name
        ys = []
        xs = []
        cols = None
        count = 1
        for p in px:
            if exclude is not None and exclude == p:
                continue
            print(".", end=" ")
            c = StorageIO.load(trialFiles.get(p).measured, StorageType.mot)
            measure = c.data.to_numpy()
            test_scale = Poop.scale(measure[:, 1:7].T, p0t.scale).T
            full_matrix = np.zeros([test_scale.shape[0], test_scale.shape[1] + 1])
            full_matrix[:, 0] = c.data['time']
            full_matrix[:, 1:7] = test_scale
            cols = ['id', 'time']
            measured_cols = [cl for cl in c.data.columns]
            for cl in measured_cols[7:13]:
                if cl not in cols:
                    cols.append(cl)

            # load in to ML Object
            measured_data = YatsdoML(full_matrix, col_names=cols)

            b = StorageIO.load(trialFiles.get(p).target, StorageType.mot)
            b_dt = b.find_dt()
            target = b.data[trialFiles.target_keys]
            target = Poop.filter_noise(target, b_dt)
            target_df = YatsdoML(target)
            endp = np.floor(target_df.time[-1])
            startp = 10
            frames = int(np.floor(0.5/b_dt))

            for i in range(0, len(target_df.time)):
                tn = target_df.time[i]
                if startp < target_df.time[i] < endp:
                    t = tn + np.asarray([n*-b_dt for n in range(0, frames)])
                    t = np.sort(t)
                    chunk = measured_data.get_samples(t, as_pandas=True, add_id=True, set_id=count)
                    xs.append(chunk.to_numpy())
                    ys.append(target_df.get_samples(tn)[1])
                    count += 1
                    pass
        print()
        tag = exclude
        if tag is None:
            tag = "All"

        chunky = pd.DataFrame(data=ys, columns=["Knee"])
        chunky.to_hdf(p0t.output_dir+"/LOO_inputs/"+tag+"_data.h5", key="y")
        ret = np.zeros([len(xs)*frames, len(cols)])
        for i in range(0, len(xs)):
            ret[i*frames: i*frames + frames, :] = xs[i]
        chunkx = pd.DataFrame(data=ret, columns=cols)

        chunkx.to_hdf(p0t.output_dir + "/LOO_inputs/" + tag + "_data.h5", key="x")
        # test outputs
        # x = pd.read_hdf(p0t.output_dir + "/LOO_inputs/" + tag + "_data.h5", key="x")
        # y = pd.read_hdf(p0t.output_dir + "/LOO_inputs/" + tag + "_data.h5", key="y")
        pass

    @staticmethod
    def chunk_and_save(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print("LOO - " + p)
            Poop.Chunk_LOO(p0t, p)
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)

    @staticmethod
    def merge_participants(p0t: Participants, exclude: str = None):
        """
        Merge data together
        :param p0t: Participants
        :param exclude: label of data to exclude
        :return:
        """
        px = p0t.participants_name
        offset = 0
        chunks = []
        chunks_y = []
        rows = 0
        cols = -1
        rows_y = 0
        cols_y = -1
        col_name = None
        col_name_y = None
        for i in range(0, len(px)):
            p = px[i]
            if exclude is not None and exclude == p:
                continue
            xs = os.listdir(trialFiles.output_dir + "/" + p + "/")
            chunk_file = [x for x in xs if "_chunks.h5" in x]
            in_dir = trialFiles.output_dir + "/" + p + "/"
            # print(in_dir + p + "_" + MLKeys.chunks.name + '.json')
            with open(in_dir + p + "_" + MLKeys.chunks.name + '.json', 'r') as infile:
                chunky_data_test = json.load(infile)
            b = StorageIO.load(trialFiles.get(p).target, StorageType.mot)
            b_dt = b.find_dt()
            target = b.data[trialFiles.target_keys]
            target = Poop.filter_noise(target, b_dt)
            target_df = YatsdoML(target)
            py = target_df.get_samples(chunky_data_test[MLKeys.timepoints.name], as_pandas=True)

            if len(chunk_file) > 0:
                fileme = trialFiles.output_dir + "/" + p + "/" + chunk_file[0]
                p_chunks = pd.read_hdf(fileme, key='chunks')
                p_chunks['id'] = p_chunks['id'] + offset
                offset = p_chunks['id'].iloc[-1]
                rows += p_chunks.shape[0]
                rows_y += py.shape[0]
                if cols == -1:
                    cols = p_chunks.shape[1]
                    col_name = [c for c in p_chunks.columns]
                if cols_y == -1:
                    cols_y = py.shape[1]
                    col_name_y = [c for c in py.columns]
                chunks.append(p_chunks)
                chunks_y.append(py)
            pass
        plate = np.zeros([rows, cols])
        plate_y = np.zeros([rows_y, cols_y])
        pointer = 0
        pointer_y = 0
        for i in range(0,len(chunks)):
            c = chunks[i]
            rows = c.shape[0]
            plate[pointer:pointer + rows] = c.to_numpy()
            pointer += rows

            y = chunks_y[i]
            rows_y = y.shape[0]
            plate_y[pointer_y:pointer_y + rows_y] = y.to_numpy()
            pointer_y += rows_y
        df = pd.DataFrame(data=plate, columns=col_name)
        dfy = pd.DataFrame(data=plate_y, columns=col_name_y)
        if exclude is not None:
            dfy.to_csv(p0t.output_dir+"/targets_LOO/"+exclude+"_y_LOO.csv", index = False)
        else:
            dfy.to_csv(p0t.output_dir + "/targets_LOO/all_y_LOO.csv", index=False)
        return {"measured": df, "target": dfy}

    @staticmethod
    def extract_features_for_merged_data_from_file(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print(p, end=" ")
            print(" -> Loading ... ", end=" ")
            x = pd.read_hdf(p0t.output_dir + "/LOO_inputs/" + p + "_data.h5", key="x")
            a = x.to_numpy()
            a2 = np.zeros([a.shape[0], 3])
            a2[:, :2] = a[:, :2]
            cols = [c for c in x.columns]
            features = {}
            params = {}
            for i in range(2, a.shape[1]):
                a2[:, 2] = a[:, i]
                df = pd.DataFrame(data=a2, columns=[cols[0], cols[1], cols[i]])
                print(" -> Extract channel: "+cols[i]+"... ")
                ef, param = MLOperations.extract_features_from_x(df)
                features[cols[i]] = ef
                params[cols[i]] = param
                print(" -> Export ... ", end=" ")
                if not os.path.exists(p0t.output_dir+"/features_LOO/"+p+"/"):
                    os.makedirs(p0t.output_dir+"/features_LOO/"+p+"/")
                MLOperations.export_features(ef,
                                             params,
                                             p0t.output_dir+"/features_LOO/"+p+"/",
                                             p + "_out_" + cols[i] + "_" + MLKeys.full_features.name,
                                             MLKeys.full_features.name
                                             )
            print("done")
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)


    @staticmethod
    def extract_features_for_merged_data(p0t: Participants):
        """
        This is an example function that runs the feature extraction pipeline for personalised ML predictive model.
        The following files will be generated as it runs:
        > Chunked data
        > Extracted Features
        > Selected Features
        """
        print("merge data")
        px = p0t.participants_name
        for p in px:
            print("Running "+p)
            data = Poop.merge_participants(p0t, p)
            print("feature extraction")
            ef, param = MLOperations.extract_features_from_x(data["measured"])
            print("feature extraction")

            # export the extracted features
            MLOperations.export_features(ef,
                                         param,
                                         p0t.output_dir,
                                         p+"_out_"+MLKeys.full_features.name,
                                         MLKeys.full_features.name
                                         )
        pass

    @staticmethod
    def feature_importance_for_merged_data(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print("Running " + p)
            print("Loading data ...")
            features = pd.read_hdf(
                p0t.output_dir+"/features_LOO/data" + p + '_out_' + MLKeys.full_features.name + '.h5',
                key=MLKeys.full_features.name)
            y = pd.read_csv(p0t.output_dir+"/targets_LOO/" + p + '_y_LOO.csv')
            print("Train")
            importance = MLOperations.train_model(features, y.iloc[:, 1])
            importance_sorted, features_names = MLOperations.sort_features_all(importance[MLKeys.feature_importance.name])
            MLOperations.sort_features_all(importance[MLKeys.feature_importance.name])
            MLOperations.export_features(importance_sorted, features_names,
                                         p0t.output_dir+"/features_LOO/",
                                         px+'_'+MLKeys.importance_sorted.name,
                                         table_id=MLKeys.importance_sorted.name)
            MLOperations.export_model(importance[MLKeys.model.name],
                                      'F:/Data/yatpkg_src/resources/ML_pipe/data/' + p + '_LOO_model.pkl')
            print("done")
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)
            pass
        pass

    @staticmethod
    def ts_selected_for_merged(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print("Running " + p)
            print("Loading data ...")
            features = pd.read_hdf(
                p0t.output_dir + "/features_LOO/data" + p + '_out_' + MLKeys.full_features.name + '.h5',
                key=MLKeys.full_features.name)
            y = pd.read_csv(p0t.output_dir + "/targets_LOO/" + p + '_y_LOO.csv')
            print("ts selector")
            features_selected = MLOperations.ts_selector(features, y.iloc[:, 1])
            feat = [col for col in features_selected.columns]
            print("write out")
            MLOperations.export_features(features_selected, feat,
                                         p0t.output_dir + "/features_LOO/tsfresh_selected/",
                                         p + "_"+MLKeys.tsfresh_selected.name,
                                         table_id=MLKeys.tsfresh_selected.name)
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)
            pass

    @staticmethod
    def scikit_importance_sort_for_merged(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        if not os.path.exists(p0t.output_dir + "/features_LOO/scikit_importance/"):
            os.makedirs(p0t.output_dir + "/features_LOO/scikit_importance/")

        for p in px:
            print("Running " + p)
            print("Loading data ...")
            e = p0t.output_dir + "/LOO_models/" + p + "_LOO_model.pkl"
            f = p0t.output_dir + "/features_LOO/tsfresh_selected/" + p + "_tsfresh_selected.h5"
            model = MLOperations.import_model(e)
            selected = pd.read_hdf(f, key=MLKeys.tsfresh_selected.name)
            print("Getting importance ...")
            importance = MLOperations.scikit_feature_importance(model, selected)
            imp = p0t.output_dir + "/features_LOO/scikit_importance/" + p + "_"+MLKeys.scikit_importance.name+".h5"
            print("exporting importance ...")
            importance.to_hdf(imp, key=MLKeys.scikit_importance.name)
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)
            pass

    @staticmethod
    def group_features(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        channels = p0t.channels_name
        for p in px:
            grouped_features = {}
            for c in channels:
                grouped_features[c] = []
            print("Running " + p)
            print("Loading data ...")
            f = p0t.output_dir + "/features_LOO/tsfresh_selected/" + p + "_tsfresh_selected.h5"
            data = pd.read_hdf(f, key=MLKeys.tsfresh_selected.name)
            print("sort into groups (channels) ...")
            count = 0
            for d in data:
                for c in channels:
                    if str(c) in str(d):
                        count += 1
                        grouped_features[c].append(d)
            pstr = "Count: {:d} | Number of Features: {:d}".format(count, data.shape[1])
            print(pstr)
            g = p0t.output_dir + "/features_LOO/grouped_features/" + p + "_grouped_features.json"
            MLOperations.export_features_json(grouped_features, g)
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)
        return grouped_features

    @staticmethod
    def top_200_from_each_channel(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        grouped_features = {}
        for p in px:
            print("Running " + p)
            print("Loading data ...")
            g = p0t.output_dir + "/features_LOO/grouped_features/" + p + "_grouped_features.json"
            groups = MLOperations.load_json(g)
            imp = p0t.output_dir + "/features_LOO/scikit_importance/" + p + "_" + MLKeys.scikit_importance.name + ".h5"
            importance = pd.read_hdf(imp, key=MLKeys.scikit_importance.name)
            for c in groups:
                channel = groups[c]
                try:
                    c_imp = importance[channel]
                except KeyError:
                    out = {}
                    for d in channel:
                        try:
                            out[d] = importance[d]
                        except KeyError:
                            print("why!!!!")

                    c_imp = pd.Series(out)
                sorted = c_imp.sort_values(ascending=False).head(200)
                grouped_features[c] = [n for n in sorted.index]

            g = p0t.output_dir + "/features_LOO/grouped_features_top200/" + p + "_grouped_features_top200.json"
            MLOperations.export_features_json(grouped_features, g)
            seconds = time.time()
            local_time = time.ctime(seconds)
            print("End - Local time:", local_time)
            pass

    @staticmethod
    def calculate_r_sq(p0t: Participants):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print("Running " + p)
            print("Loading data ...")
            gs = p0t.output_dir + "/features_LOO/grouped_features_top200/" + p + "_grouped_features_top200.json"
            fe = pd.read_hdf(
                p0t.output_dir + "/features_LOO/data" + p + '_out_' + MLKeys.full_features.name + '.h5',
                key=MLKeys.full_features.name)
            channels = MLOperations.load_json(gs)
            e = p0t.output_dir + "/LOO_models/" + p + "_LOO_model.pkl"
            model = MLOperations.import_model(e)
            y = pd.read_csv(p0t.output_dir + "/targets_LOO/" + p + '_y_LOO.csv')
            f_store = {}
            for c in channels:
                features = channels[c]
                for f in features:
                    print(f)
                    x = fe[f].to_frame()
                    try:
                        model.fit(x, y.iloc[:, 1])
                        sc = model.score(x, y.iloc[:, 1])
                        f_store[f] = float(sc)
                        print(sc)
                    except ValueError:
                        print("Why?")
            score_out = p0t.output_dir + "/features_LOO/score/" + p + "_scores.json"
            MLOperations.export_features_json(f_store, score_out)

    @staticmethod
    def filter_features(p0t: Participant):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print("Running " + p)
            print("Loading data ...")
            score_file = p0t.output_dir + "/features_LOO/score/" + p + "_scores.json"
            score = MLOperations.load_json(score_file)
            imp = p0t.output_dir + "/features_LOO/scikit_importance/" + p + "_" + MLKeys.scikit_importance.name + ".h5"
            importance = pd.read_hdf(imp, key=MLKeys.scikit_importance.name)
            score_filtered = {}
            for f in range(90, 80, -1):
                x = f/100
                for s in score:
                    if score[s] > x:
                        score_filtered[s] = score[s]
                score_labels = [c for c in score_filtered]
                if len(score_labels) > 100:
                    break
            selected = importance[score_labels].sort_values(ascending=False).head(100)
            imp_sel = p0t.output_dir + "/features_LOO/scikit_importance_sel/" + p + "_selected_" + MLKeys.scikit_importance.name + ".h5"
            selected.to_hdf(imp_sel, key=MLKeys.scikit_importance.name)
            pass

    @staticmethod
    def train_selected(p0t: Participant):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print("Running " + p)
            print("Loading data ...")
            imp_sel = p0t.output_dir + "/features_LOO/scikit_importance_sel/" + p + "_selected_" + MLKeys.scikit_importance.name + ".h5"
            importance = pd.read_hdf(imp_sel, key=MLKeys.scikit_importance.name)
            labels = [c for c in importance.index]
            features = pd.read_hdf(
                p0t.output_dir + "/features_LOO/data" + p + '_out_' + MLKeys.full_features.name + '.h5',
                key=MLKeys.full_features.name)
            y = pd.read_csv(p0t.output_dir + "/targets_LOO/" + p + '_y_LOO.csv')
            print("Select Features")
            selected = features[labels]
            print("train")
            data = MLOperations.train_model(selected, y.iloc[:, 1])
            print("export model")
            MLOperations.export_model(data[MLKeys.model.name],
                                      'F:/Data/yatpkg_src/resources/ML_pipe/data/LOOSF_model/' + p + '_LOOSF_model.pkl')

            pass

    @staticmethod
    def predict(p0t: Participant):
        seconds = time.time()
        local_time = time.ctime(seconds)
        print("Start - Local time:", local_time)
        px = p0t.participants_name
        for p in px:
            print("Running " + p)
            print("Loading data ...")
            m = 'F:/Data/yatpkg_src/resources/ML_pipe/data/LOOSF_model/' + p + '_LOOSF_model.pkl'
            model = MLOperations.import_model(m)
            imp_sel = p0t.output_dir + "/features_LOO/scikit_importance_sel/" + p + "_selected_" + MLKeys.scikit_importance.name + ".h5"
            importance = pd.read_hdf(imp_sel, key=MLKeys.scikit_importance.name)
            labels = [c for c in importance.index]
            meas = p0t.output_dir + "/" + p + "/" + p + "_chunks.h5"
            measured = pd.read_hdf(meas, key=MLKeys.chunks.name)
            features = from_columns(labels)
            ef, param = MLOperations.extract_features_from_x(measured, features=features)
            y = model.predict(ef)
            out_dir = p0t.output_dir + "/LOO_y/" + p + "_predicted_y.csv"
            pd.DataFrame(data=y, columns=["Knee Angles"]).to_csv(out_dir, index=False)
        pass

    @staticmethod
    def run_single(p0t: Participant):
        """
        This is an example function that runs the machine learning pipeline for personalised ML predictive model.
        The following files will be generated as it runs:
        > Chunked data
        > Extracted Features
        > Selected Features

        :param p0t: Participants object containing the trial information
        :return: N/A
        """
        p0x = p0t.name
        dir1 = p0t.output_dir

        # Ensures output file exists
        if not os.path.exists(dir1):
            os.makedirs(dir1)

        # read data
        print("Grab Files")
        a = p0t.value
        print(a)
        b = StorageIO.load(p0t.target, StorageType.mot)
        c = StorageIO.load(p0t.measured, StorageType.mot)
        b_dt = b.find_dt()
        c_dt = c.find_dt()
        print("filter data")
        target = b.data[p0t.target_keys]
        # this step may not be needed
        target = Poop.filter_noise(target, b_dt)
        target_df = YatsdoML(target)

        measured = c.data

        # these steps may not be needed
        measured = Poop.filter_noise(measured, c_dt)
        measured_time_matched = Poop.time_match(target, measured)

        # this is needed
        test_scale = Poop.scale(measured_time_matched[:, 1:7].T, p0t.scale).T
        full_matrix = np.zeros([test_scale.shape[0], test_scale.shape[1] + 1])
        full_matrix[:, 0] = b.data['time']
        full_matrix[:, 1:7] = test_scale
        cols = ['id', 'time']
        measured_cols = [cl for cl in measured.columns]
        for cl in measured_cols[7:13]:
            if cl not in cols:
                cols.append(cl)
        channels = cols[2:]
        # load in to ML Object
        data = YatsdoML(full_matrix, col_names=cols)
        # chunk -> save chunk
        print("chunk data")
        data.basic_chunk(offset=5)
        # -> Parameters window size -> dict
        # -> first frame, middle frame, end frame, weighted before/after -> dict
        # -> save parameters - json
        data.export_chunks(output_folder=p0t.output_dir,
                           filename=p0t.name+"_"+MLKeys.chunks.name,
                           table_id=MLKeys.chunks.name)

        # Test read in file
        with open(p0t.output_dir+p0t.name+"_"+MLKeys.chunks.name+'.json', 'r') as infile:
            chunky_data_test = json.load(infile)

        # Read in chunks
        p_chunks = pd.read_hdf(p0t.output_dir+p0t.name+"_"+MLKeys.chunks.name+'.h5', key=MLKeys.chunks.name)

        # Set target data into the ML data handler
        target_df = YatsdoML(target)

        # Get timepoints from target this is a just in case the time stamping is not constant
        py = target_df.get_samples(chunky_data_test[MLKeys.timepoints.name], as_pandas=True)

        # extract features
        # ef, param = MLOperations.extract_features_from_x(p_chunks)
        # print("feature extraction")
        #
        # # export the extracted features
        # MLOperations.export_features(ef,
        #                              param,
        #                              p0t.output_dir,
        #                              p0t.name+"_"+MLKeys.full_features.name,
        #                              MLKeys.full_features.name
        #                              )
        features = pd.read_hdf(
            p0t.output_dir+p0t.name+'_'+MLKeys.full_features.name+'.h5',
            key=MLKeys.full_features.name)
        y = py.iloc[:, 1]
        y.index = features.index
        tab = calculate_relevance_table(features, y)
        tab.to_csv(p0t.output_dir+p0t.name+'_'+"relevance_table"+'.csv', index=False)
        tab2 = pd.read_csv(p0t.output_dir+p0t.name+'_'+"relevance_table"+'.csv')
        relevant_only = tab2[tab2['relevant']]
        print(relevant_only.shape)
        relevant_list = relevant_only['feature'].to_list()
        reduce_features = features[relevant_list]
        print("train model")
        # importance = MLOperations.train_model(reduce_features, py.iloc[:, 1])
        # importance_sorted, features_names = MLOperations.sort_features_all(importance[MLKeys.feature_importance.name])
        # MLOperations.sort_features_all(importance[MLKeys.feature_importance.name])
        # MLOperations.export_features(importance_sorted, features_names,
        #                              p0t.output_dir,
        #                              p0t.name+'_'+MLKeys.importance_sorted.name,
        #                              table_id=MLKeys.importance_sorted.name)
        print("score features")
        # jsfile = p0t.output_dir+p0t.name+"_"+MLKeys.features_correlation.name+'.json'
        # MLOperations.features_r2(features,
        #                          py.iloc[:, 1],
        #                          jsfile,
        #                          p0t.temp_dir)
        importance_file = p0t.output_dir + p0t.name+'_'+MLKeys.importance_sorted.name + '.h5'
        importance_sorted: Optional[Union[pd.DataFrame, object]] = pd.read_hdf(importance_file,
                                                                               key=MLKeys.importance_sorted.name)
        # k = [ki for ki in importance_sorted.keys()]
        # print("feature select")
        # groups = {}
        # grouped_importance = {}
        # top_10_importance_per_channel = {}
        # top_10_importance_per_channel_2 = {}
        # importance_per_channel = {}
        # imp = 0
        # top_10_imp = 0
        # grouped_importance_dic = {}
        # for i in channels:
        #     featuresl = []
        #     ret_list = []
        #     re_list = []
        #     for ke in k:
        #         if i in ke:
        #             ret_list.append(ke)
        #     groups[i] = ret_list
        #     grouped_importance[i] = (importance_sorted[ret_list]).sort_values(ascending=False)
        #     grouped_importance_dic[i] = grouped_importance[i].head(200).to_dict()
        #     keg = [kd.split("__") for kd in grouped_importance[i].keys()]
        #     keg2 = [kd for kd in grouped_importance[i].keys()]
        #     for km in range(0, len(keg)):
        #         if len(keg[km]) > 3:
        #             feature_nam = keg[km][1] + keg[km][2] + keg[km][-1]
        #         elif len(keg[km]) > 4:
        #             feature_nam = keg[km][1] + keg[km][2] + keg[km][3] + keg[km][-1]
        #         else:
        #             feature_nam = keg[km][1] + keg[km][-1]
        #         try:
        #             featuresl.index(feature_nam)
        #         except ValueError:
        #             featuresl.append(feature_nam)
        #             re_list.append(keg2[km])
        #     top_10_importance_per_channel[i] = grouped_importance[i][re_list[:200]]
        #     top_10_importance_per_channel_2[i] = grouped_importance[i].head(200)
        #     importance_per_channel[i] = [np.sum(grouped_importance[i])*10,
        #                                  np.ceil(np.sum(grouped_importance[i])*10),
        #                                  np.sum(top_10_importance_per_channel[i])]
        #     imp += np.sum(grouped_importance[i])
        #     top_10_imp += np.sum(top_10_importance_per_channel[i])
        #
        # with open(p0t.output_dir+p0t.name+"_"+MLKeys.features_correlation.name+'.json',
        #           'r') as infile:
        #     feature_corr = json.load(infile)
        # importance_threhold_by_score = {}
        # importance_threhold = {}
        # for g1 in grouped_importance_dic:
        #     importance_threhold_by_score[g1] = {}
        # for g1 in grouped_importance_dic:
        #     g2 = grouped_importance_dic[g1]
        #     for g3 in g2:
        #         im = g2[g3]
        #         sc = feature_corr[g3]
        #         if sc > 0.90:
        #             importance_threhold_by_score[g1][g3] = sc
        #             importance_threhold[g3] = sc
        #         pass
        #
        # channel_feature_corr_sorted = {}
        # channel_feature_corr_sorted_names = {}
        # for i in importance_threhold_by_score:
        #     d = importance_threhold_by_score[i]
        #     factor = int(importance_per_channel[i][1]*10)
        #     channel_feature_corr_sorted[i] = (pd.Series(d)).sort_values(ascending=False).head(factor)
        #     channel_feature_corr_sorted_names[i] = [dj for dj in channel_feature_corr_sorted[i].index]
        #
        # channel_feature_corr_sorted = (pd.Series(importance_threhold)).sort_values(ascending=False).head(100)
        # channel_feature_corr_sorted_names = [dj for dj in channel_feature_corr_sorted.index]
        # selected_features = channel_feature_corr_sorted_names
        # channel_feature_corr = {}
        # for i in top_10_importance_per_channel_2:
        #     ret_lo = {}
        #     for j in top_10_importance_per_channel_2[i].index:
        #         ret_lo[j] = [feature_corr[j]]
        #     channel_feature_corr[i] = ret_lo
        # channel_feature_corr_sorted = {}
        # channel_feature_corr_sorted_names = {}
        #
        # for i in channel_feature_corr:
        #     d = channel_feature_corr[i]
        #     channel_feature_corr_sorted[i] = (pd.Series(d)).sort_values(ascending=False).head(15)
        #     channel_feature_corr_sorted_names[i] = [dj for dj in channel_feature_corr_sorted[i].index]
        #
        # selected_features = [kj for dj in channel_feature_corr_sorted_names for kj in
        #                     channel_feature_corr_sorted_names[dj]]

        selected_features = [c for c in importance_sorted.head(100).index]
        picked = from_columns(selected_features)
        efp, paramp = MLOperations.extract_features_from_x(p_chunks, features=picked)
        MLOperations.export_features(efp,
                                     paramp,
                                     'F:/Data/yatpkg_src/resources/ML_pipe/data/'+p0x+'/',
                                     "test_picked_features",
                                     'picked_features'
                                     )
        print("retrain-model with picked features")
        train_extracted, validation_extracted = MLOperations.split(efp, 0.8)
        train_y, validation_y = MLOperations.split(py["knee_angle_r"], 0.8)
        training = MLOperations.train_model(train_extracted, train_y)
        MLOperations.export_features(training["fc_selected"],
                                     training["features"],
                                     'F:/Data/yatpkg_src/resources/ML_pipe/data/'+p0x+'/',
                                     "test_model_features",
                                     'model_features'
                                     )
        MLOperations.export_model(training["model"],
                                  'F:/Data/yatpkg_src/resources/ML_pipe/data/'+p0x+'/test_model.pkl')
        model_features = MLOperations.load_json(
            'F:/Data/yatpkg_src/resources/ML_pipe/data/'+p0x+'/test_model_features.json')
        model = MLOperations.import_model(
            'F:/Data/yatpkg_src/resources/ML_pipe/data/'+p0x+'/test_model.pkl')
        model_feature_list = model_features["list"]
        results = model.predict(validation_extracted[model_feature_list])
        rms = DataError.rms(results, validation_y.to_numpy())
        print(rms)
        print()
        pass

    @staticmethod
    def count_feature_occurance():
        data_dir = "F:/Data/yatpkg_src/resources/ML_pipe/data/"
        dirlist = os.listdir(data_dir)
        picked_features_files = {}
        for p in dirlist:
            fi = data_dir+p+"/test_picked_features.json"
            if os.path.exists(fi):
                picked_features_files[p] = MLOperations.load_json(fi)['features']
        features_count = {}
        for n in picked_features_files:
            for m in picked_features_files[n]:
                try:
                    features_count[m] += 1
                except KeyError:
                    features_count[m] = 1
                pass

        features_count_sorted = (pd.Series(features_count)).sort_values(ascending=False).head(100).to_dict()
        MLOperations.export_features_json(features_count_sorted,
                                          "F:/Data/yatpkg_src/resources/ML_pipe/data/picked_features.json")
        pass

    @staticmethod
    def find_y(idx, ys=None):
        if ys is None:
            ys = os.listdir('F:/Data/yatpkg_src/resources/ML_pipe/target/')

        for i in ys:
            if i.lower().startswith(idx.lower()):
                return i

    @staticmethod
    def export_new_common_feature_list(tar=[]):

        picked_features = MLOperations.load_json("F:/Data/yatpkg_src/resources/ML_pipe/data/picked_features.json")
        features = from_columns([p for p in picked_features.keys()])
        data_dir = 'F:/Data/yatpkg_src/resources/ML_pipe/data/'
        p0x_list = os.listdir(data_dir)
        results_subject_specific = {}
        for p0x in p0x_list:
            if not os.path.isdir(data_dir + p0x):
                continue
            results_subject_specific[p0x] = {}

        for p0x in p0x_list:
            #p0x = "P07"
            print(p0x)
            if not p0x.startswith("P"):
                continue
            if not os.path.isdir(data_dir + p0x):
                continue
            p_file = data_dir + p0x + '/'+p0x+'_chunks.h5'
            p_chunks = pd.read_hdf(p_file, key='chunks')
            tar_file = data_dir + p0x + '/'+p0x+'_chunks.json'
            with open(tar_file, 'r') as infile:
                chunky_data_test = json.load(infile)
            file = Poop.find_y(p0x)
            target_df = YatsdoML('F:/Data/yatpkg_src/resources/ML_pipe/target/'+file, col_names=tar)
            py = target_df.get_samples(chunky_data_test["timepoints"], as_pandas=True)

            efp, paramp = MLOperations.extract_features_from_x(p_chunks, features=features)
            MLOperations.export_features(efp,
                                         paramp,
                                         'F:/Data/yatpkg_src/resources/ML_pipe/',
                                         "test_picked_features",
                                         'picked_features'
                                         )

            train_extracted, validation_extracted = MLOperations.split(efp, 0.7)
            train_y, validation_y = MLOperations.split(py["knee_angle_r"], 0.7)
            training = MLOperations.train_model(train_extracted, train_y)
            MLOperations.export_features(training["fc_selected"],
                                         training["features"],
                                         'F:/Data/yatpkg_src/resources/ML_pipe/',
                                         "test_model_features",
                                         'model_features'
                                         )
            MLOperations.export_model(training["model"],
                                      'F:/Data/yatpkg_src/resources/ML_pipe/test_model.pkl')
            MLOperations.export_model(training["model"],
                                      'F:/Data/yatpkg_src/resources/ML_pipe/test_model.pkl')
            model_features = MLOperations.load_json(
                'F:/Data/yatpkg_src/resources/ML_pipe/test_model_features.json')
            model = MLOperations.import_model(
                'F:/Data/yatpkg_src/resources/ML_pipe/test_model.pkl')
            model_feature_list = model_features["list"]
            model_feature_list2 = paramp['features']
            results = training["model"].predict(validation_extracted[model_feature_list])
            results2 = training["model"].predict(train_extracted[model_feature_list])
            r2 = model.score(validation_extracted[model_feature_list], validation_y.to_numpy())
            rms, std = DataError.rms(results, validation_y.to_numpy())
            rms2, std2 = DataError.rms(results2, train_y.to_numpy())
            print(rms)
            print(rms2)

            results_subject_specific[p0x]["RMS-training"] = rms
            results_subject_specific[p0x]["Std-training"] = std
            results_subject_specific[p0x]["RMS"] = rms2
            results_subject_specific[p0x]["Std"] = std2
            results_subject_specific[p0x]["R2"] = r2
            print()
        df: pd.DataFrame = pd.DataFrame(results_subject_specific)
        df = df.transpose()
        df.to_csv('F:/Data/yatpkg_src/resources/ML_pipe/results_solo.csv')
        pass

    @staticmethod
    def mean_correlation_of_picked():
        picked_features = MLOperations.load_json("F:/Data/yatpkg_src/resources/ML_pipe/data/picked_features.json")
        data_dir = 'F:/Data/yatpkg_src/resources/ML_pipe/data/'
        p0x_list = os.listdir(data_dir)
        results_feature_corr = {}
        results_feature_importance = {}
        for fx in picked_features:
            results_feature_corr[fx] = []
            results_feature_importance[fx] = []

        for p0x in p0x_list:
            if not os.path.isdir(data_dir+p0x):
                continue
            tfc = MLOperations.load_json(data_dir+p0x+'/'+p0x+'_features_correlation.json')
            importance = pd.read_hdf(
                data_dir+p0x+'/'+p0x+"_importance_sorted.h5",
                key='importance_sorted')
            dict_importance = importance.to_dict()
            for fx in picked_features:
                results_feature_corr[fx].append(tfc[fx])
                try:
                    results_feature_importance[fx].append(dict_importance[fx])
                except KeyError:
                    pass
        results_features = {}
        index = 0
        for fx in picked_features:
            results_features[index] = {}
            index += 1
        index = 0
        for fx in picked_features:
            results_features[index]['Features'] = fx
            results_features[index]['R2'] = np.nanmean(results_feature_corr[fx])
            results_features[index]['Mean Important'] = np.nanmean(results_feature_importance[fx])
            results_features[index]['Max Importance'] = np.nanmax(results_feature_importance[fx])
            results_features[index]['Min Importance'] = np.nanmin(results_feature_importance[fx])
            results_features[index]['Number of Participants'] = picked_features[fx]/10
            index += 1
        df = pd.DataFrame(results_features).transpose()
        df.to_csv(data_dir+"feature_results.csv", index=False)

    @staticmethod
    def get_features_vs_y(participant, filepath, tar=[]):
        # Read Top Ten
        fil = filepath+participant.name+"/"
        features_fil = fil+"test_full_features.h5"
        features = pd.read_hdf(features_fil, "full_features")
        list_me = pd.read_csv(filepath+"feature_sorted.csv")
        top_10 = list_me["Features"].iloc[:10].to_list()
        ret = {}
        for t in top_10:
            x = features[t].to_numpy()
            tar_file = fil + '/test.json'
            with open(tar_file, 'r') as infile:
                chunky_data_test = json.load(infile)
            file = Poop.find_y(participant.name)
            target_df = YatsdoML('F:/Data/yatpkg_src/resources/ML_pipe/target/' + file, col_names=tar)
            y = target_df.get_samples(chunky_data_test["timepoints"], as_pandas=False)[:, 1]
            ret[t] = {'x': x, 'y': y}
        return ret

    @staticmethod
    def r2_check():
        r2 = MLOperations.load_json('F:/Data/yatpkg_src/resources/ML_pipe/feature_analysis/picked_features_r2.json')
        nor2 = MLOperations.load_json('F:/Data/yatpkg_src/resources/ML_pipe/feature_analysis/picked_features_no_r2.json')
        r2_list = [[c, r2[c]] for c in r2]
        nor2_list = [[c, nor2[c]] for c in nor2]
        r2_df = pd.DataFrame(r2_list, columns=["feature", "count"])
        nor2_df = pd.DataFrame(nor2_list, columns=["feature", "count"])
        r2_df.to_csv('F:/Data/yatpkg_src/resources/ML_pipe/feature_analysis/picked_features_r2.csv', index=False)
        nor2_df.to_csv('F:/Data/yatpkg_src/resources/ML_pipe/feature_analysis/picked_features_no_r2.csv', index=False)
        not_in_r2 = []
        for c in r2:
            try:
                nor2[c]
            except KeyError:
                not_in_r2.append([c, r2[c]])
        not_in_nor2 = []
        for c in nor2:
            try:
                r2[c]
            except KeyError:
                not_in_nor2.append([c, nor2[c]])
        r2_df_none = pd.DataFrame(not_in_r2, columns=["feature", "count"])
        nor2_df_none = pd.DataFrame(not_in_nor2, columns=["feature", "count"])
        pass


if __name__ == '__main__':
    filepath = "F:/Data/yatpkg_src/resources/"
    trialFiles = Participants.load(filepath + "trialfiles.json")

    #Poop.chunk_and_save(trialFiles)
    # Poop.merge_participants(trialFiles)
    # Poop.chunk_and_save(trialFiles)
    # Poop.extract_features_for_merged_data_from_file(trialFiles)
    # Poop.merge_channels(trialFiles)
    # Poop.train(trialFiles)

    # Poop.extract_features_for_merged_data(trialFiles)
    # Poop.feature_importance_for_merged_data(trialFiles)
    # Poop.ts_selected_for_merged(trialFiles)
    # Poop.scikit_importance_sort_for_merged(trialFiles)
    # Poop.group_features(trialFiles)
    # Poop.top_200_from_each_channel(trialFiles)
    # Poop.calculate_r_sq(trialFiles)
    # Poop.filter_features(trialFiles)
    # Poop.train_selected(trialFiles)
    # Poop.predict(trialFiles)

    # px = trialFiles.participants_name
    # px = ['P11', 'P13', 'P15', 'P16', 'P17']+
    # px1 = trialFiles.participants
    # for px0 in range(0, len(px)):
    #     pxi = trialFiles.get(px[px0])
    #     Poop.run_single(pxi)

    # Poop.count_feature_occurance()
    Poop.export_new_common_feature_list(tar=['time', 'knee_angle_r'])
    # Poop.mean_correlation_of_picked()

    # Poop.r2_check()

    #filepath = "F:/Data/yatpkg_src/resources/ML_pipe/data/"
    # px = ['P07', 'P08', 'P09', 'P12', 'P10', 'P11', 'P13', 'P15', 'P16', 'P17']
    # data = {}
    # for px0 in range(0, len(px)):
    #     pxi = trialFiles.get(px[px0])
    #     data[px[px0]] = Poop.get_features_vs_y(pxi, filepath+"ML_pipe/data/", tar=['time', 'knee_angle_r'])
    # features_set = {}
    # print(len(data.keys()))
    # for d in data:
    #     for f in data[d]:
    #         features_set[f] = {}
    #
    # for d in data:
    #     for f in data[d]:
    #         features_set[f][d] = data[d][f]
    #
    # for p in px:
    #     indexs = 0
    #     for f in features_set:
    #         figs = plt.figure()
    #         d = features_set[f][p]
    #         plt.plot(d['x'], d['y'], 'o')
    #         plt.xlabel(f)
    #         plt.ylabel("Knee Flexion Angle (Degrees)")
    #     #plt.legend(list(features_set[f].keys()))
    #         if not os.path.exists(filepath+p+'/figs/'):
    #             os.makedirs(filepath+p+'/figs/')
    #         plt.savefig(filepath+p+'/figs/figure '+str(indexs)+'.png', dpi=600)
    #         indexs += 1
    #         plt.close(figs)

    print()
