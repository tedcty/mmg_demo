from enum import Enum


class MLKeys(Enum):
    """
    This enum class contains the most commonly used tags in the mlde package
    """
    dir_x = 0
    dir_y = 1
    x_file = 2
    y_file = 3
    y_labels = 4
    x_labels = 5
    CFCParameters = 6
    MFCParameters = 7
    ModelName = 8
    AdditionalInfo = 9
    training = 10
    validation = 11
    train_and_validate = 12
    feature_importance = 13
    full_features = 14
    importance_sorted = 15
    chunks = 16
    model = 17
    features = 18
    timepoints = 19
    window = 20
    offset = 21
    id = 22
    features_correlation = 23
    tsfresh_selected = 24
    scikit_importance = 25



