import sys
from PyQt5.QtWidgets import QApplication
from yatpkg.gui.node.components import MainWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)
    screen = app.screens()
    for s in screen:
        dpi = s.logicalDotsPerInch()
        print(dpi)
    w = MainWindow()
    sys.exit(app.exec_())
